extern "C"
{
int pthread_sort(int num_of_elements, float *data);
int fpga_sort(int num_of_elements, float *data);
}