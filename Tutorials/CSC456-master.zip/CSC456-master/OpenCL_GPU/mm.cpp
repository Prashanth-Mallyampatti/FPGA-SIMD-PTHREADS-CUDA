#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <OpenCL/opencl.h>
#include <ctime>
//#include "matrixMult.h"

int ARRAY_SIZE = 128;  

// OpenCL runtime configuration

cl_mem gpu_a, gpu_b, gpu_c;
static int LoadTextFromFile(
    const char *file_name, char **result_string, size_t *string_len);
void cleanup();
double getCurrentTimestamp();
#define LOCAL_MEM_SIZE = 1024;
void _checkError(int line,
								 const char *file,
								 cl_int error,
                 const char *msg,
                 ...);

#define checkError(status, ...) _checkError(__LINE__, __FILE__, status, __VA_ARGS__)

int main (int argc, const char * argv[]) {
  int i;
//  #ifdef OUTPUT
  int j;
//  #endif
  char name[128];
  float *a, *b, *c;
  int err;                            // error code returned from api calls
  cl_device_id device_id;             // compute device id 
  cl_context context;                 // compute context
  cl_command_queue queue;          // compute command queue
  cl_program program;                 // compute program
  cl_kernel kernel;                   // compute kernel
  static cl_program ComputeProgram;

  int mode =0;
  if(argc >= 2)
    ARRAY_SIZE = atoi(argv[1]);
  mode = atoi(argv[2]);
  a = (float *)malloc(ARRAY_SIZE*ARRAY_SIZE*sizeof(cl_float));
  if(a == NULL)
   fprintf(stderr,"allocating array a failed\n");
  for(i = 0; i < ARRAY_SIZE*ARRAY_SIZE; i++)
      a[i] = (cl_float)rand();

  b = (float *)malloc(ARRAY_SIZE*ARRAY_SIZE*sizeof(cl_float));
  if(b == NULL)
   fprintf(stderr,"allocating array b failed\n");

  for(i = 0; i < ARRAY_SIZE*ARRAY_SIZE; i++)
      b[i] = (cl_float)rand();

  c = (float *)malloc(ARRAY_SIZE*ARRAY_SIZE*sizeof(cl_float));
  if(c == NULL)
   fprintf(stderr,"allocating array c failed\n");

// initialize OpenCL
  cl_int status;

  printf("Initializing OpenCL\n");
  int gpu = 1;
  err = clGetDeviceIDs(NULL, gpu ? CL_DEVICE_TYPE_GPU : CL_DEVICE_TYPE_CPU, 1, &device_id, NULL);
  if (err != CL_SUCCESS)
  {
     fprintf(stderr, "Error: Failed to create a device group!\n");
     return EXIT_FAILURE;
  }

  // Create a compute context 
  //
  context = clCreateContext(0, 1, &device_id, NULL, NULL, &err);
  if (!context)
  {
     fprintf(stderr,"Error: Failed to create a compute context!\n");
     return EXIT_FAILURE;
  }

  queue = clCreateCommandQueue(context, device_id, 0, &err);
  if (!queue)
  {
     fprintf(stderr,"Error: Failed to create a command commands!\n");
     return EXIT_FAILURE;
  }  

  // Kernel.
  char *source = 0;
  size_t length = 0;
  err = LoadTextFromFile("mm.cl", &source, &length);
  const char *kernel_name = "matrix_mul";
  program = clCreateProgramWithSource(context, 1, (const char **) & source, NULL, &err);
  err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
  if (err != CL_SUCCESS)
  {
          size_t len;
        char buffer[2048];
 
        printf("Error: Failed to build program executable!\n");
        clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, sizeof(buffer), buffer, &len);
        printf("%s\n", buffer);
        exit(1);
  }
  kernel = clCreateKernel(program, kernel_name, &err);
  if (err != CL_SUCCESS)
  {  
    fprintf(stderr, "Failed to create kernel");
    exit(1);
  }

    gpu_a = clCreateBuffer(context, CL_MEM_READ_ONLY,
        ARRAY_SIZE * ARRAY_SIZE * sizeof(float), NULL, &err);
  if (err != CL_SUCCESS)
  {  
    fprintf(stderr, "Failed to create buffer for input A");
    exit(1);
  }

    gpu_b = clCreateBuffer(context, CL_MEM_READ_ONLY,
        ARRAY_SIZE * ARRAY_SIZE * sizeof(float), NULL, &err);
  if (err != CL_SUCCESS)
  {  
    fprintf(stderr, "Failed to create buffer for input B");
    exit(1);
  }

    gpu_c = clCreateBuffer(context, CL_MEM_WRITE_ONLY,
        ARRAY_SIZE * ARRAY_SIZE * sizeof(float), NULL, &status);
  if (err != CL_SUCCESS)
  {  
    fprintf(stderr, "Failed to create buffer for output C");
    exit(1);
  }

    err = clEnqueueWriteBuffer(queue, gpu_a, CL_FALSE,
        0, ARRAY_SIZE * ARRAY_SIZE * sizeof(float), a, 0, NULL, NULL);
  if (err != CL_SUCCESS)
  {  
    fprintf(stderr, "Failed to transfer buffer for output C");
    exit(1);
  }

    err = clEnqueueWriteBuffer(queue, gpu_b, CL_FALSE,
        0, ARRAY_SIZE * ARRAY_SIZE * sizeof(float), b, 0, NULL, NULL);
  if (err != CL_SUCCESS)
  {  
    fprintf(stderr, "Failed to transfer buffer for output C");
    exit(1);
  }

    clFinish(queue);
    
    cl_event kernel_event;
    double start_time = getCurrentTimestamp();

    unsigned argi = 0;

    status = clSetKernelArg(kernel, argi++, sizeof(cl_mem), &gpu_a);
    checkError(status, "Failed to set argument %d", argi - 1);

    status = clSetKernelArg(kernel, argi++, sizeof(cl_mem), &gpu_b);
    checkError(status, "Failed to set argument %d", argi - 1);

    status = clSetKernelArg(kernel, argi++, sizeof(cl_mem), &gpu_c);
    checkError(status, "Failed to set argument %d", argi - 1);

    status = clSetKernelArg(kernel, argi++, sizeof(ARRAY_SIZE), &ARRAY_SIZE);
    checkError(status, "Failed to set argument %d", argi - 1);

    size_t max_work_size[2];
    size_t global_work_size[2] = {ARRAY_SIZE, ARRAY_SIZE};
    size_t local_work_size[2]  = {8, 8};

    status = clEnqueueNDRangeKernel(queue, kernel, 2, NULL,
        global_work_size, local_work_size, 0, NULL, &kernel_event);
    checkError(status, "Failed to launch kernel");

  // Wait for all kernels to finish.
   clFinish(queue);
  //clWaitForEvents(num_devices, &kernel_event);

  double end_time = getCurrentTimestamp();
  double total_time = end_time - start_time;

  // Wall-clock time taken.
  printf("\nTime: %0.3f ms\n", total_time * 1e3);
  const float flops = (float)(2.0f * ARRAY_SIZE * ARRAY_SIZE * ARRAY_SIZE/ total_time);
  printf("\nThroughput: %0.2f GFLOPS\n\n", flops * 1e-9);

  clReleaseEvent(kernel_event);
    status = clEnqueueReadBuffer(queue, gpu_c, CL_TRUE,
        0, ARRAY_SIZE * ARRAY_SIZE * sizeof(float), c, 0, NULL, NULL);
    checkError(status, "Failed to read output matrix");

   clFinish(queue);
#ifdef OUTPUT
  for(i = 0; i < ARRAY_SIZE; i++)
  {
    for(j = 0; j < ARRAY_SIZE; j++)
      fprintf(stderr, "%lf ",c[i*ARRAY_SIZE+j]);
    fprintf(stderr, "\n");
  }
#endif
   if(kernel) {
      clReleaseKernel(kernel);
    }
    if(queue) {
      clReleaseCommandQueue(queue);
    }
    if(gpu_a) {
      clReleaseMemObject(gpu_a);
    }
    if(gpu_b) {
      clReleaseMemObject(gpu_b);
    }
    if(gpu_c) {
      clReleaseMemObject(gpu_c);
    }

  if(program) {
    clReleaseProgram(program);
  }
  if(context) {
    clReleaseContext(context);
  }
  free(a);
  free(b);
  free(c);
//  dispatch_release(queue);
  cleanup();
  return 0;
}

void cleanup() {
}

static int LoadTextFromFile(
    const char *file_name, char **result_string, size_t *string_len)
{
    int fd;
    unsigned file_len;
    struct stat file_status;
    int ret;
 
    *string_len = 0;
    fd = open(file_name, O_RDONLY);
    if (fd == -1)
    {
        printf("Error opening file %s\n", file_name);
        return -1;
    }
    ret = fstat(fd, &file_status);
    if (ret)
    {
        printf("Error reading status for file %s\n", file_name);
        return -1;
    }
    file_len = file_status.st_size;
 
    *result_string = (char*)calloc(file_len + 1, sizeof(char));
    ret = read(fd, *result_string, file_len);
    if (!ret)
    {
        printf("Error reading from file %s\n", file_name);
        return -1;
    }
 
    close(fd);
 
    *string_len = file_len;
    return 0;
}

// High-resolution timer.
double getCurrentTimestamp() {
#ifdef _WIN32 // Windows
  // Use the high-resolution performance counter.

  static LARGE_INTEGER ticks_per_second = {};
  if(ticks_per_second.QuadPart == 0) {
    // First call - get the frequency.
    QueryPerformanceFrequency(&ticks_per_second);
  }

  LARGE_INTEGER counter;
  QueryPerformanceCounter(&counter);

  double seconds = double(counter.QuadPart) / double(ticks_per_second.QuadPart);
  return seconds;
#else         // Linux
  timespec a;
  clock_gettime(CLOCK_MONOTONIC, &a);
  return (double(a.tv_nsec) * 1.0e-9) + double(a.tv_sec);
#endif
}

void _checkError(int line,
								 const char *file,
								 cl_int error,
                 const char *msg,
                 ...) {
	// If not successful
	if(error != CL_SUCCESS) {
		// Print line and file
    printf("ERROR: ");
    printf("\nLocation: %s:%d\n", file, line);

    // Print custom message.
    va_list vl;
    va_start(vl, msg);
    vprintf(msg, vl);
    printf("\n");
    va_end(vl);

    // Cleanup and bail.
    cleanup();
    exit(error);
	}
}