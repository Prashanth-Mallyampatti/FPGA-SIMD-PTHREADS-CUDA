#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

volatile int a,b;
volatile int x,y;
volatile int f;
void* modifya(void *z)
{
  a=1;
  x=b;
  return NULL;
}
void* modifyb(void *z)
{
  b=1;
  y=a;
  return NULL;
}

int main()
{
  int i;
  pthread_t thread[2];
  pthread_create(&thread[0], NULL, modifya, NULL);
  pthread_create(&thread[1], NULL, modifyb, NULL);
  fprintf(stderr,"Before join: (%d, %d)\n",x,y);
  pthread_join(thread[0], NULL);
  pthread_join(thread[1], NULL);
  fprintf(stderr,"After join: (%d, %d)\n",x,y);
  return 0;
}
