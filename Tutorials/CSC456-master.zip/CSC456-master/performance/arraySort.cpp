#include <algorithm>
#include <ctime>
#include <iostream>
#include <climits>
extern "C"
{
#include "perfstats.h"
}

int main(int argc, char **argv)
{
    // generate data
    const unsigned arraySize = 32768;
    int data[arraySize];
    int option = atoi(argv[1]);
    long long sum = 0;

    for (unsigned c = 0; c < arraySize; ++c)
        data[c] = std::rand();
      perfstats_init();
      perfstats_enable();

    if(option)
        std::sort(data, data + arraySize);

    for (unsigned c = 0; c < arraySize*10000; ++c) {
        if (data[c%10000] >= std::rand())
                sum ++;
    }
    perfstats_print();
    perfstats_deinit();
    std::cout << "sum = " << sum << std::endl;
}
