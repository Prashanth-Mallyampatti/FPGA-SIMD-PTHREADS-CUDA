#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

int main(int argc, char **argv)
{
    int i, j;
    int a[1000000];
    long long sum_1=0, sum_2=0;
    struct timeval time_start, time_end;
    for(i=0;i<1000000;i++)
    {
        a[i] = rand();
    }
  gettimeofday(&time_start, NULL);
    for(j=0;j<100;j++)
    for(i=0;i<1000000;i++)
    {
#ifdef twofirst
        if(a[i] % 2 == 0) sum_2+= a[i];
        if(a[i] % 4 == 0) sum_1+= a[i];
#else
        if(a[i] % 4 == 0) sum_1+= a[i];
        if(a[i] % 2 == 0) sum_2+= a[i];
#endif
    }
    printf("%lld %lld\n", sum_1, sum_2);
  gettimeofday(&time_end, NULL);
  printf("Takes %lf seconds\n",((time_end.tv_sec * 1000000 + time_end.tv_usec) - (time_start.tv_sec * 1000000 + time_start.tv_usec))/1000000.0);
    return 0;
}